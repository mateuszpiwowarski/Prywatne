/*
 * Unified sketch for PlatformIO.
 * Generated from original multi-file Arduino project.
 */


// ===== BEGIN MPe-firmware.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

// Configuration
#include "MPe-configuration.h"

// Custom serial print functions
#include "MPe-PrintWithSC.h"
PrintWithSC mySerial(Serial);

// EEPROM Save&Load
#include "EEPROMex.h"

#ifdef PAS
// POWER PID
#include "PID_v1.h"
float pPID_Set, pPID_In, pPID_Out;
PID powerPID(&pPID_In, &pPID_Out, &pPID_Set, 0.1, 0.1, 0.1, 1, EEPROM.readInt(ADR_PIDPWMMAX)); //, DIRECT);
#endif

#ifdef OLED1
// DISPLAY
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1306.h"
#include "DejaVu_LGC_Sans_Mono_Bold_20.h"
Adafruit_SSD1306 display(4);
#endif

// ADS1115 ADC 15bit
#include "Adafruit_ADS1015.h"
Adafruit_ADS1115 ads;

// WATCHDOG
#include <avr/wdt.h>

// Expotential Filter
#include "Filter.h"
ExponentialFilter<float>  pin_current_mV_filtered(10.0, 2480.0);
ExponentialFilter<float> vRef_filtered(10.0, 5.0);
ExponentialFilter<float> pin_voltage_mV_filtered(20.0, 2800.0);
ExponentialFilter<float> pin_temp1_V_filtered(3.0, 0.3);
ExponentialFilter<float> pin_temp2_V_filtered(3.0, 0.3);
ExponentialFilter<float> pas_rpm_ex(20.0, 0.0);
ExponentialFilter<float> speed_filtered(40.0, 0.0);
ExponentialFilter<float> weightOnPedal_adc_filtered(50.0, 0);
ExponentialFilter<float> humanPower_adc_filtered(15.0, 0);

bool b_up_p = false;
bool b_up_lp = false;
bool b_dwn_p = false;
bool b_dwn_lp = false;
bool b_updwn_p = false;
bool stopped = true;
bool cruisecontrol = false;
bool screenconfig = false;
bool screenconfig_just_entered = false;
bool temperatureOK = true;
bool brake = true;
bool throttle_relased_reset = true;
bool last_brake = true;
#ifdef CONFIG_MENU
bool configchanged = false;
#endif
bool statscreen = false;
bool rideOK = false;
bool pas_after_power_throttle = false;

volatile int rotation_impulses = 0;
#ifdef PAS
volatile int pas_rotation_impulses = 0;
#endif
volatile int speedOneimpulseTime = 0;
volatile bool speed_impulse = false;
volatile unsigned long timer_speed_one = 0;

int screen = 1;
int cruisecontrol_pwm = 0;
#ifdef CONFIG_MENU
int configCursor = 1;
#endif
int last_dtg = 0;
int last_assistmode = 0;
int address = 0;
int pwmOut = 0;
int voltageOut = 80;
int speedFactor = 100;

float powermax = 0.0;
float imax = 0.0;
float Wh_used = 0.0;
float Wh_used_trp = 0.0;
float Wh_used_dtg = 0.0;
float vRef = 5.0;
#ifdef MTG
float Wh_used_mtg = 0.0;
float moving_time_mtg = 0;
float last_mtg = 0.0;
float total_mh = 0.0;
#endif
float mah_used = 0.0;
float total_ah_used = 0.0;
float speed = 0.0;
float vmax = 0.0;
float dist = 0.0;
float trip = 0.0;
float trip_dtg = 0.0;
float moving_time = 0.0;
float cruisecontrol_speed = 0.0;

#ifdef PAS
unsigned long timer_pas_rpm = 0;
#endif
unsigned long timer_100ms_loop = 0;
unsigned long timer_30ms_loop = 0;
unsigned long timer_speed = 0;
unsigned long timer_button = 0;
unsigned long timer_refresh = 0;
unsigned long timer_send_uart = 0;
unsigned long timer_stopped = 0;
unsigned long timer_no_pedalling = 0;
unsigned long timer_adc_offset = 0;
unsigned long timer_value_delay_1 = 0;
unsigned long timer_value_delay_2 = 0;

#ifdef TESTING
unsigned long timer_speedtesting = 0;
unsigned long timer_randomtesting = 0;
float randomcurrent = 0.0;
float randomtemp1 = 0.0;
float randomtemp2 = 0.0;
int randomspeedms = 50;
#endif

#ifdef TEST_LOOP_SPEED
unsigned long timer_loopspeed = 0;
int loopcount = 0;
int looptime = 0;
#endif

float adc_offset = 0.0;
bool adc_will_save = 0;
bool adc_saved = 1;

#ifdef LIGHT_OPERATION
bool D4_state = 0;
bool D9_state = 0;
bool LCD_dark = 0;
#endif

void setup()
{

  Serial.begin(9600);
  Serial.setTimeout(50); // serial.parseint hangs for 1s without it

  // PINMODE
  pinMode(PIN_THROTTLE_OUT, OUTPUT);
  analogWrite(PIN_THROTTLE_OUT, 0);

  pinMode(PIN_BUTTON_UP, INPUT_PULLUP);
  pinMode(PIN_BUTTON_DOWN, INPUT_PULLUP);
  pinMode(PIN_BRAKE, INPUT_PULLUP);

  if ((EEPROM.readInt(ADR_MOT_MAG) > 1))
    attachInterrupt(digitalPinToInterrupt(PIN_DSPEED), mot_rot, FALLING);
  else
    attachInterrupt(digitalPinToInterrupt(PIN_DSPEED), speed_one, FALLING);

  // UNUSED PINS ANALOG
  pinMode(A2, INPUT_PULLUP); // UNUSED PIN
  pinMode(A6, INPUT_PULLUP); // UNUSED PIN
  pinMode(A7, INPUT_PULLUP); // UNUSED PIN

  // Torque sensor
  pinMode(A3, INPUT);

#ifndef LIGHT_OPERATION
  pinMode(4, INPUT_PULLUP);
#endif

#if not defined LIGHT_OPERATION
  pinMode(9, INPUT_PULLUP);
#endif

#ifdef LIGHT_OPERATION
  pinMode(4, OUTPUT);
  pinMode(9, OUTPUT);
  digitalWrite(4, LOW);
  D4_state = 0;
  digitalWrite(9, LOW);
  D9_state = 0;
#endif

  pinMode(10, INPUT_PULLUP);
  pinMode(11, INPUT_PULLUP);
  pinMode(12, INPUT_PULLUP);
  pinMode(13, INPUT_PULLUP);

#ifdef OLED1
  // LCD Init
  screenReset();
  display.display();
#endif

  // EEPROMex
  if (EEPROM.readInt(ADRFIRSTTIME) == FIRST_TIME_CODE)
  // if(1)
  {
    loadData();

#ifdef INITIAL
    display.clearDisplay();
    display.setFont();
    display.setTextSize(2);
    display.setTextColor(WHITE);
    display.setCursor(11, 0);
    display.println("LBAD BK"); // Not used characters removed from glcdfont.c / actual characters changed their position
    // display.println("LOAD OK");
    display.display();
    while (true)
      ;
#endif
  }
#ifndef INITIAL
  else
  {
    while (true)
      ;
  }
#endif
#ifdef INITIAL
  else
  {

    for (int i = 2; i < 512; i += 2)
    {
      EEPROM.updateInt(i, 55555);
    }

    initialConfigSave();

    display.clearDisplay();
    display.setFont();
    display.setTextSize(2);
    display.setTextColor(WHITE);
    display.setCursor(11, 0);
    display.println("I?I; BK"); // Not used characters removed from glcdfont.c / actual characters changed their position
    // display.println("INIT OK");
    display.display();

    while (true)
      ;
  }
#endif

  // ADS INIT
  ads.begin();

  // Acu Full Charge Check & reset
  float vol = 0.0;

  for (int i = 0; i < 3; i++)
    vol = getBatRawVoltage();

  if (vol > (eepromLoadFloat(ADRLASTVOLTAGE) + 2.0))
  {
    resetBattery();
  }

  // TEMP INIT
  pin_temp1_V_filtered.SetCurrent(0.005 * analogRead(PIN_LM35_TEMP_T1));
  pin_temp2_V_filtered.SetCurrent(0.005 * analogRead(PIN_LM35_TEMP_T2));

  // Enable print out for bluetooth
  EEPROM.updateInt(ADR_PRINTINFO, 1);
  // #endif
#ifdef SERIALPLOT
  // EEPROM.updateInt(ADR_PRINTINFO,0);
  EEPROM.updateInt(ADR_SERIAL_PLOT, 0);
#endif

  // Always start with legal mode
  if (EEPROM.readInt(ADR_AUTOLEGAL) && !EEPROM.readInt(ADR_WATCHDOGRESET))
  {
    EEPROM.updateInt(ADR_LEGALLIMIT_ON_OFF, 1);
  }

  // Watchdog

  enable_watchdog();
  EEPROM.updateInt(ADR_WATCHDOGRESET, 0);
}

void loop()
{
#ifdef TEST_LOOP_SPEED
  timer_loopspeed = millis();
#endif

  // every loop
  wdt_reset();
  serialConfig();
  setThrottle();
  checkButtons();

  // 100ms
  if ((millis() - timer_100ms_loop) > T100MS_LOOP)
  {

    checkVRef();
    set_adc_offset();
    checkEbrake();
    checkTemp();
    checkIfrideOK();
#ifdef PAS
    checkTorque();
#endif

    timer_100ms_loop = millis();
  }

  // 30ms
  speed_one_check();
  checkCurrentAndVoltage();

  // 250ms
  countSpeed();

  // 1000 / 2500ms
  checkIfStopped();

  // 500ms
#ifdef PAS
  checkCadence();
#endif

  // 500ms
  screenRefresh();

  serialPrintInfo();

#ifdef TESTING
  if (millis() - timer_speedtesting > randomspeedms)
  {
    timer_speedtesting = millis();
    mot_rot();
  }

  if (millis() - timer_randomtesting > 2000)
  {
    timer_randomtesting = millis();
    testRandom();
  }
#endif

#ifdef TEST_LOOP_SPEED
  int time = millis() - timer_loopspeed;
  loopcount++;
  looptime += time;
  if (loopcount == 20)
  {
    Serial.println(looptime / 20);
    loopcount = 0;
    looptime = 0;
  }
#endif

  // test watchog
  /*  if (millis() > 10000)
    {
    while(1);
    } */
}

// ===== END MPe-firmware.ino =====


// ===== BEGIN MPe-brake.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

void checkEbrake()
{
  bool br = digitalRead(PIN_BRAKE);
  if (br == EEPROM.readInt(ADR_EBRAKEHILO))
  {
    brake = true;

    if (EEPROM.readInt(ADR_THR_RESET) && (speed < 3.0))
      SetThrRelResetFALSE();
  }
  else
    brake = false;
}

// ===== END MPe-brake.ino =====


// ===== BEGIN MPe-eeprom.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

void saveData()
{
  EEPROM.updateFloat(ADRDIST, dist);
  EEPROM.updateFloat(ADRWHUSED, Wh_used);
  EEPROM.updateFloat(ADRVMAX, vmax);
  EEPROM.updateFloat(ADRMVTIME, moving_time);
  EEPROM.updateFloat(ADRTRIP, trip);
  EEPROM.updateFloat(ADRWHUSEDKM, Wh_used_trp);
  EEPROM.updateFloat(ADRPMAX, powermax);
  EEPROM.updateFloat(ADRIMAX, imax);
  EEPROM.updateFloat(ADRMAHUSED, mah_used);
  EEPROM.updateFloat(ADRWHUSEDKMDTG, Wh_used_dtg);
  EEPROM.updateFloat(ADRTRIPDTG, trip_dtg);
  EEPROM.updateFloat(ADRTOTMAHUSED, total_ah_used);

  if (getCurrent() < 1.5)
    EEPROM.updateFloat(ADRLASTVOLTAGE, getBatRawVoltage());
#ifdef MTG
  EEPROM.updateFloat(ADRWHUSEDMTG, Wh_used_mtg);
  EEPROM.updateFloat(ADRMVTIMEMTG, moving_time_mtg);
  EEPROM.updateFloat(ADRTOTMH, total_mh);
#endif
}

#ifdef INITIAL
void initialConfigSave()
{
  EEPROM.updateInt(ADRFIRSTTIME, FIRST_TIME_CODE);

  // used in savaData(); and loadData();
  EEPROM.updateFloat(ADRDIST, 0.0);
  EEPROM.updateFloat(ADRWHUSED, 0.0);
  EEPROM.updateFloat(ADRVMAX, 0.0);
  EEPROM.updateFloat(ADRMVTIME, 0.0);
  EEPROM.updateFloat(ADRTRIP, 0.0);
  EEPROM.updateFloat(ADRWHUSEDKM, 0.0);
  EEPROM.updateFloat(ADRPMAX, 0.0);
  EEPROM.updateFloat(ADRIMAX, 0.0);
  EEPROM.updateFloat(ADRMAHUSED, 0.0);
  EEPROM.updateFloat(ADRWHUSEDKMDTG, 0.0);
  EEPROM.updateFloat(ADRTRIPDTG, 0.0);
  EEPROM.updateFloat(ADRTOTMAHUSED, 0.0);
  EEPROM.updateFloat(ADRLASTVOLTAGE, 95.0);
  EEPROM.updateFloat(ADRWHUSEDMTG, 0.0);
  EEPROM.updateFloat(ADRMVTIMEMTG, 0.0);
  EEPROM.updateFloat(ADRTOTMH, 0.0);

  EEPROM.updateFloat(ADR0CURRENT, 0.0);
  EEPROM.updateInt(ADR_WATCHDOGRESET, 0);

#ifdef INIT_3000W

  EEPROM.updateInt(ADR_ASSISTMODE, 3);
  EEPROM.updateInt(ADR_BATCAP_AH, 192);
  EEPROM.updateInt(ADR_BATCAP_WH, 1114);
  EEPROM.updateInt(ADR_LVC, 390);
  EEPROM.updateInt(ADR_FULL_BATT_V, 540);
  EEPROM.updateInt(ADR_MVPERA, 40);
  EEPROM.updateInt(ADR_CURDIR, 0);
  EEPROM.updateInt(ADR_VOL_DIV, 33058);
  EEPROM.updateInt(ADR_CUR_SENSOR_OK, 0);
  EEPROM.updateInt(ADR_CUR_PROT, 2);

  EEPROM.updateInt(ADR_TOT_MIN, 79);
  EEPROM.updateInt(ADR_TOT_MAX, 360);
  EEPROM.updateInt(ADR_TIN_MIN, 90);
  EEPROM.updateInt(ADR_TIN_MAX, 380);
  EEPROM.updateInt(ADR_THR_RESET, 1);
  EEPROM.updateInt(ADR_THR_SAFE_VOLTAGE, 390);

  EEPROM.updateInt(ADR_KPHMPH, 0);
  EEPROM.updateInt(ADR_PERIMETER, 2163);
  EEPROM.updateInt(ADR_MOT_MAG, 1);
  EEPROM.updateInt(ADR_GEAR_RATIO, 10);

  EEPROM.updateInt(ADR_BT_BUTTONS, 0);
  EEPROM.updateInt(ADR_EBRAKEHILO, 0);

  EEPROM.updateInt(ADR_TEMPCTEMPF, 0);
  EEPROM.updateInt(ADR_TEMPTYPE1, 3);
  EEPROM.updateInt(ADR_TEMPTYPE2, 1);
  EEPROM.updateInt(ADR_OVHT1, 140);
  EEPROM.updateInt(ADR_OVHT2, 60);

  EEPROM.updateInt(ADR_POWERKP, 150);
  EEPROM.updateInt(ADR_POWERKI, 80);
  EEPROM.updateInt(ADR_POWERKD, 50);
  EEPROM.updateInt(ADR_P_LOW, 0);
  EEPROM.updateInt(ADR_I_LOW, 0);
  EEPROM.updateInt(ADR_D_LOW, 0);
  EEPROM.updateInt(ADR_LOW_THRESHOLD, 0);

  EEPROM.updateInt(ADR_SPEEDFACTORMIN, 1);

  EEPROM.updateInt(ADR_PIDPWMMAX, 200);

  EEPROM.updateInt(ADR_SPEEDFACTOR_RAMP_UP, 40);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_MIN, 240);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_MAX, 1300);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_RAMP_UP, 300);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_MAX_SPEED, 40);

  EEPROM.updateInt(ADR_AUTOLEGAL, 1);
  EEPROM.updateInt(ADR_LEGALLIMIT_ON_OFF, 1);
  EEPROM.updateInt(ADR_LEGALLIMIT_SPEED, 25);
  EEPROM.updateInt(ADR_LEGALLIMIT_POWER, 250);
  EEPROM.updateInt(ADR_PASMAGNETS, 12);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_1, 100);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_2, 180);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_3, 250);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_4, 350);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_5, 600);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_1, 20);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_2, 25);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_3, 25);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_4, 30);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_5, 38);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_1, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_2, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_3, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_4, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_5, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_1, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_2, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_3, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_4, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_5, 0);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_1, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_2, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_3, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_4, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_5, 10);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_1, 300);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_2, 300);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_3, 300);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_4, 400);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_5, 500);

  EEPROM.updateInt(ADR_BOOST_POWER_PAS_1, 500);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_2, 500);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_3, 750);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_4, 800);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_5, 1000);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_1, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_2, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_3, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_4, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_5, 3500);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_1, 10);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_2, 10);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_3, 10);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_4, 22);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_5, 30);
  EEPROM.updateInt(ADR_BOOST_RAMP_UP_PAS, 5000);
  EEPROM.updateInt(ADR_CADENCE_COUNT_TIME, 250);
  EEPROM.updateInt(ADR_ENABLE_TORQUE_SENSOR, 0);
  EEPROM.updateInt(ADR_STARTUP_WEIGHT_ON_PEDAL, 180);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_ADC_MIN, 315);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_ADC_MAX, 620);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_KGF_MAX, 600);

  EEPROM.updateInt(ADR_PWR_LIM_THR_1, 100);
  EEPROM.updateInt(ADR_PWR_LIM_THR_2, 250);
  EEPROM.updateInt(ADR_PWR_LIM_THR_3, 500);
  EEPROM.updateInt(ADR_PWR_LIM_THR_4, 1000);
  EEPROM.updateInt(ADR_PWR_LIM_THR_5, 1000);
  EEPROM.updateInt(ADR_MODE_THR_1, 0);
  EEPROM.updateInt(ADR_MODE_THR_2, 0);
  EEPROM.updateInt(ADR_MODE_THR_3, 0);
  EEPROM.updateInt(ADR_MODE_THR_4, 1);
  EEPROM.updateInt(ADR_MODE_THR_5, 1);
  EEPROM.updateInt(ADR_RAMP_UP_THR_1, 3000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_2, 3000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_3, 3000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_4, 3000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_5, 3000);

#endif

#ifdef INIT_10000W

  EEPROM.updateInt(ADR_ASSISTMODE, 3);
  EEPROM.updateInt(ADR_BATCAP_AH, 440);
  EEPROM.updateInt(ADR_BATCAP_WH, 3190);
  EEPROM.updateInt(ADR_LVC, 600);
  EEPROM.updateInt(ADR_FULL_BATT_V, 835);
  EEPROM.updateInt(ADR_MVPERA, 10);
  EEPROM.updateInt(ADR_CURDIR, 1);
  EEPROM.updateInt(ADR_VOL_DIV, 33058);
  EEPROM.updateInt(ADR_CUR_SENSOR_OK, 0);
  EEPROM.updateInt(ADR_CUR_PROT, 20);

  EEPROM.updateInt(ADR_TOT_MIN, 85);
  EEPROM.updateInt(ADR_TOT_MAX, 350);
  EEPROM.updateInt(ADR_TIN_MIN, 90);
  EEPROM.updateInt(ADR_TIN_MAX, 360);
  EEPROM.updateInt(ADR_THR_RESET, 1);
  EEPROM.updateInt(ADR_THR_SAFE_VOLTAGE, 370);

  EEPROM.updateInt(ADR_KPHMPH, 0);
  EEPROM.updateInt(ADR_PERIMETER, 2050);
  EEPROM.updateInt(ADR_MOT_MAG, 32);
  EEPROM.updateInt(ADR_GEAR_RATIO, 10);

  EEPROM.updateInt(ADR_BT_BUTTONS, 0);
  EEPROM.updateInt(ADR_EBRAKEHILO, 1);

  EEPROM.updateInt(ADR_TEMPCTEMPF, 0);
  EEPROM.updateInt(ADR_TEMPTYPE1, 4);
  EEPROM.updateInt(ADR_TEMPTYPE2, 0);
  EEPROM.updateInt(ADR_OVHT1, 140);
  EEPROM.updateInt(ADR_OVHT2, 60);

  EEPROM.updateInt(ADR_POWERKP, 190);
  EEPROM.updateInt(ADR_POWERKI, 100);
  EEPROM.updateInt(ADR_POWERKD, 80);
  EEPROM.updateInt(ADR_P_LOW, 0);
  EEPROM.updateInt(ADR_I_LOW, 0);
  EEPROM.updateInt(ADR_D_LOW, 0);
  EEPROM.updateInt(ADR_LOW_THRESHOLD, 0);

  EEPROM.updateInt(ADR_SPEEDFACTORMIN, 1);

  EEPROM.updateInt(ADR_PIDPWMMAX, 70);

  EEPROM.updateInt(ADR_SPEEDFACTOR_RAMP_UP, 30);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_MIN, 240);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_MAX, 2000);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_RAMP_UP, 260);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_MAX_SPEED, 40);

  EEPROM.updateInt(ADR_AUTOLEGAL, 1);
  EEPROM.updateInt(ADR_LEGALLIMIT_ON_OFF, 0);
  EEPROM.updateInt(ADR_LEGALLIMIT_SPEED, 25);
  EEPROM.updateInt(ADR_LEGALLIMIT_POWER, 250);
  EEPROM.updateInt(ADR_PASMAGNETS, 12);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_1, 500);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_2, 700);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_3, 900);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_4, 1100);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_5, 1100);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_1, 20);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_2, 25);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_3, 30);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_4, 35);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_5, 35);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_1, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_2, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_3, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_4, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_5, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_1, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_2, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_3, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_4, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_5, 0);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_1, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_2, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_3, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_4, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_5, 10);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_1, 200);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_2, 200);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_3, 400);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_4, 500);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_5, 500);

  EEPROM.updateInt(ADR_BOOST_POWER_PAS_1, 2000);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_2, 2000);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_3, 2000);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_4, 2000);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_5, 2000);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_1, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_2, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_3, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_4, 3500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_5, 3500);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_1, 10);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_2, 10);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_3, 22);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_4, 27);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_5, 27);
  EEPROM.updateInt(ADR_BOOST_RAMP_UP_PAS, 5000);
  EEPROM.updateInt(ADR_CADENCE_COUNT_TIME, 250);
  EEPROM.updateInt(ADR_ENABLE_TORQUE_SENSOR, 0);
  EEPROM.updateInt(ADR_STARTUP_WEIGHT_ON_PEDAL, 180);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_ADC_MIN, 315);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_ADC_MAX, 620);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_KGF_MAX, 600);

  EEPROM.updateInt(ADR_PWR_LIM_THR_1, 1000);
  EEPROM.updateInt(ADR_PWR_LIM_THR_2, 35);
  EEPROM.updateInt(ADR_PWR_LIM_THR_3, 35);
  EEPROM.updateInt(ADR_PWR_LIM_THR_4, 50);
  EEPROM.updateInt(ADR_PWR_LIM_THR_5, 100);
  EEPROM.updateInt(ADR_MODE_THR_1, 1);
  EEPROM.updateInt(ADR_MODE_THR_2, 0);
  EEPROM.updateInt(ADR_MODE_THR_3, 0);
  EEPROM.updateInt(ADR_MODE_THR_4, 0);
  EEPROM.updateInt(ADR_MODE_THR_5, 0);
  EEPROM.updateInt(ADR_RAMP_UP_THR_1, 1000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_2, 500);
  EEPROM.updateInt(ADR_RAMP_UP_THR_3, 500);
  EEPROM.updateInt(ADR_RAMP_UP_THR_4, 2000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_5, 2000);

#endif

#ifdef INIT_6000W

  EEPROM.updateInt(ADR_ASSISTMODE, 5);
  EEPROM.updateInt(ADR_BATCAP_AH, 400);
  EEPROM.updateInt(ADR_BATCAP_WH, 2890);
  EEPROM.updateInt(ADR_LVC, 600);
  EEPROM.updateInt(ADR_FULL_BATT_V, 830);
  EEPROM.updateInt(ADR_MVPERA, 10);
  EEPROM.updateInt(ADR_CURDIR, 0);
  EEPROM.updateInt(ADR_VOL_DIV, 33187);
  EEPROM.updateInt(ADR_CUR_SENSOR_OK, 0);
  EEPROM.updateInt(ADR_CUR_PROT, 30);

  EEPROM.updateInt(ADR_TOT_MIN, 85);
  EEPROM.updateInt(ADR_TOT_MAX, 350);
  EEPROM.updateInt(ADR_TIN_MIN, 90);
  EEPROM.updateInt(ADR_TIN_MAX, 370);
  EEPROM.updateInt(ADR_THR_RESET, 1);
  EEPROM.updateInt(ADR_THR_SAFE_VOLTAGE, 370);

  EEPROM.updateInt(ADR_KPHMPH, 0);
  EEPROM.updateInt(ADR_PERIMETER, 1890);
  EEPROM.updateInt(ADR_MOT_MAG, 46);
  EEPROM.updateInt(ADR_GEAR_RATIO, 10);

  EEPROM.updateInt(ADR_BT_BUTTONS, 0);
  EEPROM.updateInt(ADR_EBRAKEHILO, 1);

  EEPROM.updateInt(ADR_TEMPCTEMPF, 0);
  EEPROM.updateInt(ADR_TEMPTYPE1, 3);
  EEPROM.updateInt(ADR_TEMPTYPE2, 1);
  EEPROM.updateInt(ADR_OVHT1, 120);
  EEPROM.updateInt(ADR_OVHT2, 60);

  EEPROM.updateInt(ADR_POWERKP, 200);
  EEPROM.updateInt(ADR_POWERKI, 70);
  EEPROM.updateInt(ADR_POWERKD, 140);
  EEPROM.updateInt(ADR_P_LOW, 50);
  EEPROM.updateInt(ADR_I_LOW, 30);
  EEPROM.updateInt(ADR_D_LOW, 50);
  EEPROM.updateInt(ADR_LOW_THRESHOLD, 300);

  EEPROM.updateInt(ADR_SPEEDFACTORMIN, 1);

  EEPROM.updateInt(ADR_PIDPWMMAX, 200);

  EEPROM.updateInt(ADR_SPEEDFACTOR_RAMP_UP, 50);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_MIN, 240);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_MAX, 1300);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_POWER_RAMP_UP, 300);
  EEPROM.updateInt(ADR_CRUISE_CONTROL_MAX_SPEED, 40);

  EEPROM.updateInt(ADR_AUTOLEGAL, 1);
  EEPROM.updateInt(ADR_LEGALLIMIT_ON_OFF, 0);
  EEPROM.updateInt(ADR_LEGALLIMIT_SPEED, 28);
  EEPROM.updateInt(ADR_LEGALLIMIT_POWER, 350);
  EEPROM.updateInt(ADR_PASMAGNETS, 36);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_1, 5);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_2, 10);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_3, 15);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_4, 20);
  EEPROM.updateInt(ADR_PWR_LIM_PAS_5, 1100);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_1, 55);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_2, 55);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_3, 55);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_4, 55);
  EEPROM.updateInt(ADR_SPD_LIM_PAS_5, 37);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_1, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_2, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_3, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_4, 0);
  EEPROM.updateInt(ADR_MIN_SPD_PAS_5, 3);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_1, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_2, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_3, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_4, 0);
  EEPROM.updateInt(ADR_CAD_MIN_PAS_5, 0);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_1, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_2, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_3, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_4, 10);
  EEPROM.updateInt(ADR_CAD_MAX_PAS_5, 10);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_1, 350);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_2, 350);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_3, 350);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_4, 350);
  EEPROM.updateInt(ADR_RAMP_UP_PAS_5, 350);

  EEPROM.updateInt(ADR_BOOST_POWER_PAS_1, 500);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_2, 500);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_3, 800);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_4, 1100);
  EEPROM.updateInt(ADR_BOOST_POWER_PAS_5, 1000);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_1, 1500);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_2, 2000);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_3, 2000);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_4, 2000);
  EEPROM.updateInt(ADR_BOOST_TIME_PAS_5, 1500);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_1, 20);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_2, 25);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_3, 55);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_4, 55);
  EEPROM.updateInt(ADR_BOOST_SPEED_PAS_5, 29);
  EEPROM.updateInt(ADR_BOOST_RAMP_UP_PAS, 5000);
  EEPROM.updateInt(ADR_CADENCE_COUNT_TIME, 250);
  EEPROM.updateInt(ADR_ENABLE_TORQUE_SENSOR, 1);
  EEPROM.updateInt(ADR_STARTUP_WEIGHT_ON_PEDAL, 100);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_ADC_MIN, 325);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_ADC_MAX, 620);
  EEPROM.updateInt(ADR_TORQUE_SENSOR_KGF_MAX, 750);

  EEPROM.updateInt(ADR_PWR_LIM_THR_1, 60);
  EEPROM.updateInt(ADR_PWR_LIM_THR_2, 100);
  EEPROM.updateInt(ADR_PWR_LIM_THR_3, 100);
  EEPROM.updateInt(ADR_PWR_LIM_THR_4, 100);
  EEPROM.updateInt(ADR_PWR_LIM_THR_5, 100);
  EEPROM.updateInt(ADR_MODE_THR_1, 0);
  EEPROM.updateInt(ADR_MODE_THR_2, 0);
  EEPROM.updateInt(ADR_MODE_THR_3, 0);
  EEPROM.updateInt(ADR_MODE_THR_4, 0);
  EEPROM.updateInt(ADR_MODE_THR_5, 0);
  EEPROM.updateInt(ADR_RAMP_UP_THR_1, 3500);
  EEPROM.updateInt(ADR_RAMP_UP_THR_2, 5000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_3, 5000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_4, 5000);
  EEPROM.updateInt(ADR_RAMP_UP_THR_5, 5000);

#endif
}
#endif

float eepromLoadFloat(int adr)
{
  float value = 0.0;
  value = EEPROM.readFloat(adr);
  return value;
}

void loadData()
{
  dist = eepromLoadFloat(ADRDIST);
  Wh_used = eepromLoadFloat(ADRWHUSED);
  vmax = eepromLoadFloat(ADRVMAX);
  moving_time = eepromLoadFloat(ADRMVTIME);
  trip = eepromLoadFloat(ADRTRIP);
  Wh_used_trp = eepromLoadFloat(ADRWHUSEDKM);
  powermax = eepromLoadFloat(ADRPMAX);
  imax = eepromLoadFloat(ADRIMAX);
  mah_used = eepromLoadFloat(ADRMAHUSED);
  Wh_used_dtg = eepromLoadFloat(ADRWHUSEDKMDTG);
  trip_dtg = eepromLoadFloat(ADRTRIPDTG);
  total_ah_used = eepromLoadFloat(ADRTOTMAHUSED);
#ifdef MTG
  moving_time_mtg = eepromLoadFloat(ADRMVTIMEMTG);
  Wh_used_mtg = eepromLoadFloat(ADRWHUSEDMTG);
  total_mh = eepromLoadFloat(ADRTOTMH);
#endif
}

// ===== END MPe-eeprom.ino =====


// ===== BEGIN MPe-oled-buttons.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

void checkButtons()
{

  bool b_up = !digitalRead(PIN_BUTTON_UP);
  bool b_dwn = !digitalRead(PIN_BUTTON_DOWN);

  bool test100 = millisMinusTimerButton() > 100;

  // BOTH CLICK

  if (b_up && b_dwn && !b_updwn_p)
  {
    b_updwn_p = true;
    b_dwn_p = true;
    b_dwn_lp = true;
    b_up_p = true;
    b_up_lp = true;
    resetTimerButton();
  }

  if ((!b_up || !b_dwn) && b_updwn_p)
  {
#ifdef OLED1
    screenReset();
#endif
    UPDWNDepressedAction();
    b_updwn_p = false;
    b_dwn_p = false;
    b_dwn_lp = false;
    b_up_p = false;
    b_up_lp = false;
    resetTimerButton();
  }

  // UP CLICK
  if (b_up && !b_up_p && test100)
  {
    b_up_p = true;
    resetTimerButton();
  }

  if (!b_up && b_up_p && !b_up_lp)
  {
    if (test100)
    {
#ifdef OLED1
      screenReset();
#endif
      UPDepressedAction();
    }
    b_up_p = false;
    b_up_lp = false;
  }

  // DOWN CLICK
  if (b_dwn && !b_dwn_p && test100)
  {
    b_dwn_p = true;
    resetTimerButton();
  }

  if (!b_dwn && b_dwn_p && !b_dwn_lp)
  {
    if (test100)
    {
#ifdef OLED1
      screenReset();
#endif
      DWNDepressedAction();
    }
    b_dwn_p = false;
    b_dwn_lp = false;
  }

  // UPDWN LONG CLICK
  if (b_updwn_p && (millisMinusTimerButton() > 2000))
  {
    UPDWNLongPressedAction();
  }

  // UP LONG CLICK
  if (b_up && b_up_p && !b_up_lp)
  {
    if ((millisMinusTimerButton() > 500))
    {
      resetTimerButton();
      b_up_lp = true;
      UPLongPressedAction();
    }
  }

  if (!b_up && b_up_p && b_up_lp)
  {
    // UPLongDepressedAction();
    b_up_p = false;
    b_up_lp = false;
  }

  // DOWN LONG CLICK
  if (b_dwn && b_dwn_p && !b_dwn_lp)
  {
    if (millisMinusTimerButton() > 500)
    {
      b_dwn_lp = true;
      resetTimerButton();
      DWNLongPressedAction();
    }
  }

  if (!b_dwn && b_dwn_p && b_dwn_lp)
  {
    // DWNLongDepressedAction();
    b_dwn_p = false;
    b_dwn_lp = false;
  }
}

void UPDWNDepressedAction()
{
  if (!EEPROM.readInt(ADR_BT_BUTTONS) && !screenconfig)
  {
    statscreen = !statscreen;
    if (screen == 1)
      screen = 2;
    else
      screen = 1;
  }

  if (screenconfig && !screenconfig_just_entered)
  {
    screenconfig = 0;
    statscreen = 0;
    screen = 1;
  }

  if (screenconfig_just_entered)
    screenconfig_just_entered = false;
}

void UPDWNLongPressedAction()
{
  if (!screenconfig)
  {
    screenconfig = true;
    screenconfig_just_entered = true;
  }
}

void UPDepressedAction()
{

#ifdef OLED1

  if (!cruisecontrol && !screenconfig && statscreen)
  {
    if (screen < NUM_SCREEN_POSITIONS)
      screen++;
    else
      screen = 2;
  }

  if (screen == 1 && !screenconfig && !cruisecontrol)
  {
    int assist = EEPROM.readInt(ADR_ASSISTMODE);
    cruisecontrol = false;
    assist += 1;
    if (assist > 5)
      assist = 5;
    EEPROM.updateInt(ADR_ASSISTMODE, assist);
    SetThrRelResetFALSE();
    // powerPID.RESET();
  }

  if (cruisecontrol)
  {
    cruisecontrol = false;
  }

#ifdef CONFIG_MENU
  if (screenconfig && !configchanged)
    selectConfig(configCursor, 1);
  else
    configchanged = false;
#endif

#endif

#ifndef OLED1
  cruisecontrol = false;
#endif
}

void UPLongPressedAction()
{
  speedUpCruiseControl();

#ifdef CONFIG_MENU
  if (screenconfig)
  {

    if (configCursor < 9)
    {
      configCursor += 1;
    }

    resetTimerButton();
    b_up_lp = false;
    configchanged = true;
  }
#endif
}

void DWNDepressedAction()
{
  if (screen == 1 && !screenconfig && !cruisecontrol && !brake)
  {
    int assist = EEPROM.readInt(ADR_ASSISTMODE);
    assist -= 1;
    if (assist < 0)
      assist = 0;
    EEPROM.updateInt(ADR_ASSISTMODE, assist);
    SetThrRelResetFALSE();
  }

#ifdef OLED1
  if ((!cruisecontrol && !screenconfig && statscreen))
  {
    if (screen > 2)
      screen--;
    else
      screen = NUM_SCREEN_POSITIONS;
  }

  if (cruisecontrol)
  {
    cruisecontrol = false;
  }

#ifdef CONFIG_MENU
  if (screenconfig && !configchanged)
    selectConfig(configCursor, 0);
  else
    configchanged = false;
#endif

#endif

#ifndef OLED1
  cruisecontrol = false;
#endif
}

void DWNLongPressedAction()
{
  if (!screenconfig)
    enableCruiseControl();

  slowDownCruiseControl();

#ifdef PAS
  if (screen == 1 && brake)
  {
    if (EEPROM.readInt(ADR_LEGALLIMIT_ON_OFF))
      EEPROM.updateInt(ADR_LEGALLIMIT_ON_OFF, 0);
    else
      EEPROM.updateInt(ADR_LEGALLIMIT_ON_OFF, 1);
  }

#endif

#ifdef OLED1
  if (screen == 2 && !screenconfig)
  {
    zeroTrip();
  }

  if (screen == 3 && !screenconfig)
  {
    resetCurrentAt0();
  }

  if (screen == 4 && !screenconfig)
  {
    resetBattery();
  }

#endif

#ifdef CONFIG_MENU

  if (screenconfig)
  {

    if (configCursor > 1)
    {
      configCursor -= 1;
    }

    resetTimerButton();
    b_dwn_lp = false;
    configchanged = true;
  }

#endif
}

void resetTimerButton()
{
  timer_button = millis();
}

unsigned int millisMinusTimerButton()
{
  return millis() - timer_button;
}

// ===== END MPe-oled-buttons.ino =====


// ===== BEGIN MPe-oled-display.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

#ifdef OLED1
void screenReset()
{

  if (!screenconfig)
  {
    display.begin(SSD1306_SWITCHCAPVCC, SSD1306_I2C_ADDRESS, false);
  }
}
#endif

void screenRefresh()
{
#ifndef SERIALPLOT
  if ((millis() - timer_refresh > SCREENREFRESH) && (millis() > 2500))
#endif

#ifdef SERIALPLOT
    if ((millis() - timer_refresh > SCREENREFRESH) && (millis() > 2500) && (!EEPROM.readInt(ADR_SERIAL_PLOT)))
#endif
    {
      timer_refresh = millis();
#ifdef OLED1
      display.clearDisplay();
      // SCREEN RESOLUTION 128x32

      switch (screen)
      {
      case 1:
        screen1();
        break;
      case 2:
        screen2();
        break;
      case 3:
        screen3();
        break;
      case 4:
        screen4();
        break;
      case 5:
        screen5();
        break;

#ifdef MTG
      case 6:
        screen_MhWh();
        break;
#endif
      }

#ifdef CONFIG_MENU
      if (screenconfig)
      {
        display.clearDisplay();
        screenConfig();
      }
#endif

      display.display();
#endif
    }
}

#ifdef OLED1

void setFont2WHITE()
{
  display.setFont();
  display.setTextSize(2);
  display.setTextColor(WHITE);
}

void screen1()
{
  display.setFont();
  display.setRotation(0);
  display.setTextSize(2);

  // ASSIST MODE
  if (EEPROM.readInt(ADR_LEGALLIMIT_ON_OFF))
  {
    display.fillRect(114, 16, 12, 16, WHITE);
    display.setTextColor(BLACK);
  }
  display.setCursor(115, 17);
  display.println(EEPROM.readInt(ADR_ASSISTMODE));

  display.setTextColor(WHITE);

#ifndef MTG
  display.setCursor(intAlignRight(int(distToGo())), 0);
  display.println(int(distToGo()));
#endif

#ifdef MTG
  display.setCursor(intAlignRight(int(minutesToGo())), 0);
  display.println(int(minutesToGo()));
#endif

  display.setCursor(64, 18); // decimal speed
  display.println(int(speed * 10) % 10);

  display.setCursor(65, 0);
  char txt = ' ';
  if (brake)
    txt = '*';
  else if (cruisecontrol && rideOK)
    txt = 'J'; // Not used characters removed from glcdfont.c / actual characters changed their position
  else if (!rideOK)
    txt = '!';

  display.println(txt);

  // Descriptions
  display.setTextSize(1);
  display.setRotation(3);

  // SPEED UNIT
  display.setCursor(0, 0);

  if (EEPROM.readInt(ADR_KPHMPH))
  {
    // display.println("mph");
    display.println("$%'"); // Not used characters removed from glcdfont.c / actual characters changed their position
    display.setCursor(19, 118);
    // display.println("mi");
    display.println("$\""); // Not used characters removed from glcdfont.c / actual characters changed their position
  }
  else
  {
    // display.println("km/h");
    display.println("#$/'"); // Not used characters removed from glcdfont.c / actual characters changed their position
    display.setCursor(19, 118);
#ifndef MTG
    // display.println("km");
    display.println("#$"); // Not used characters removed from glcdfont.c / actual characters changed their position
#endif
#ifdef MTG
    // display.println("mt");
    display.println("$&"); // Not used characters removed from glcdfont.c / actual characters changed their position
#endif
  }

  display.setRotation(0);
  display.setFont(&DejaVu_LGC_Sans_Mono_Bold_20); // speed
  display.setTextSize(2);
  display.setCursor(10, 32);

  if (int(speed) < 10)
    display.print(0);

  if (speed >= 100)
  {
    speed = int(speed) % 100;
    display.fillRect(0, 0, 8, 32, BLACK);
    display.setCursor(-10, 32);
    display.print(1);
    display.setCursor(10, 32);
    if (speed < 10)
      display.print(0);
  }
  display.println(int(speed));

  display.fillRect(60, 30, 1, 2, WHITE); // coma

#define STARTX 80 // battery symbol   size
#define STARTY 16
#define SIZEX 29
#define SIZEY 16
#define SIZEXF 43

  display.drawRect(STARTX, STARTY, SIZEX, SIZEY, WHITE);
  display.fillRect(STARTX + SIZEX, STARTY + 2, 2, SIZEY - 4, WHITE);
  display.fillRect(STARTX + 2, STARTY + 2, (SIZEX - 4) * acuPercent() / 100, SIZEY - 4, WHITE);
  display.drawRect(STARTX + int((SIZEX) / 4), STARTY + 2, 1, SIZEY - 4, BLACK);       // 10     STARTX+ int((SIZEX-4)/4)
  display.drawRect(STARTX + (int((SIZEX) / 4)) * 2, STARTY + 2, 1, SIZEY - 4, BLACK); // 19
  display.drawRect(STARTX + (int((SIZEX) / 4)) * 3, STARTY + 2, 1, SIZEY - 4, BLACK); // 28
}

void screen2()
{
  setFont2WHITE();

  // MAX Speed  //TOP LEFT
  display.setCursor(11, 0);
  display.println(vmax, 0);

  // Average Speed  //DOWN LEFT
  display.setCursor(11, 16);
  display.println(avgSpeed(), 0);

  // Trip distance  //TOP RIGHT
  display.setCursor(floatAlignRight(trip), 0);
  display.println(trip, 1);

  // Moving time  //DOWN RIGHT
  display.setCursor(intAlignRight(moving_time), 16);
  display.println(moving_time, 0);

  // Descriptions
  display.setRotation(3);
  display.setTextSize(1);

  // TOP LEFT
  display.setCursor(19, 0);
  // display.println("MX");
  display.println("@("); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN LEFT
  display.setCursor(3, 0);
  // display.println("AV");
  display.println("A:"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // TOP RIGHT
  display.setCursor(19, 119);
  // display.println("TR");
  display.println(";="); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN RIGHT
  display.setCursor(3, 119);
  // display.println("MT");
  display.println("@;"); // Not used characters removed from glcdfont.c / actual characters changed their position

  display.setRotation(0);
}

void screen3()
{
  setFont2WHITE();

  // Voltage  //TOP LEFT
  display.setCursor(11, 0);
  if (getBatVoltage() > 100.0 || getPower() > 9999)
    display.println(getBatVoltage(), 0);
  else
    display.println(getBatVoltage(), 1);

  // Current  //DOWN LEFT
  display.setCursor(11, 16);
  if (getCurrent() > 100.0 || powermax > 9999)
    display.println(getCurrent(), 0);
  else
    display.println(getCurrent(), 1);

  // Power  //TOP RIGHT
  float pwr = abs(getPower());
  display.setCursor(intAlignRight(pwr), 0);
  display.println(pwr, 0);

  // MAX Power  //DOWN RIGHT
  display.setCursor(intAlignRight(powermax), 16);
  display.println(powermax, 0);

  // Descriptions
  display.setRotation(3);
  display.setTextSize(1);

  // TOP LEFT
  display.setCursor(22, 0);
  // display.println("U");
  display.println(")"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN LEFT
  display.setCursor(6, 0);
  display.println("I"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // TOP RIGHT
  display.setCursor(22, 119);
  // display.println("P");
  display.println(">"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN RIGHT
  display.setCursor(3, 119);
  // display.println("PM");
  display.println(">@"); // Not used characters removed from glcdfont.c / actual characters changed their position

  display.setRotation(0);
}

void screen4()
{
  setFont2WHITE();

  // I MAX   //TOP LEFT
  display.setCursor(11, 0);
  display.println(imax, 0);

  // Wh / km  //DOWN LEFT
  display.setCursor(11, 16);
  display.println(whkm(), 1);

  // Wh used  //TOP RIGHT
  display.setCursor(intAlignRight(int(Wh_used)), 0);
  display.println(Wh_used, 0);

  // Amp hours used  //DOWN RIGHT
  display.setCursor(floatAlignRight(mah_used / 1000), 16);
  display.println(mah_used / 1000, 1);

  // Descriptions
  display.setRotation(3);
  display.setTextSize(1);

  // TOP LEFT
  display.setCursor(19, 0);
  // display.println("IM");
  display.println("I@"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN LEFT
  display.setCursor(3, 0);
  // display.println("WK");
  display.println("+K"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // TOP RIGHT
  display.setCursor(19, 119);
  // display.println("WU");
  display.println("+)"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN RIGHT
  display.setCursor(3, 119);
  // display.println("AU");
  display.println("A)"); // Not used characters removed from glcdfont.c / actual characters changed their position

  display.setRotation(0);
}

void screen5()
{
  setFont2WHITE();

  // Temp Controller  //TOP LEFT
  display.setCursor(11, 0);
  display.println(getTemp_1());

  // Temp Motor  //DOWN LEFT
  display.setCursor(11, 16);
  display.println(getTemp_2());

  // Overall distance  //TOP RIGHT
  display.setCursor(intAlignRight(int(dist)), 0);
  display.println(dist, 0);

  // Number of charging cycles  //DOWN RIGHT
  display.setCursor(intAlignRight(numberCharges()), 16);
  display.println(numberCharges());

  // Descriptions
  display.setRotation(3);
  display.setTextSize(1);

  // TOP LEFT
  display.setCursor(19, 0);
  // display.println("T1");
  display.println(";1"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN LEFT
  display.setCursor(3, 0);
  // display.println("T2");
  display.println(";2"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // TOP RIGHT
  display.setCursor(19, 119);
  // display.println("DS");
  display.println("D<"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN RIGHT
  display.setCursor(3, 119);
  // display.println("NC");
  display.println("?C"); // Not used characters removed from glcdfont.c / actual characters changed their position

  display.setRotation(0);
}

#endif

#ifdef MTG
void screen_MhWh()
{
  setFont2WHITE();

  // Temp Controller  //TOP LEFT
  display.setCursor(11, 0);
  display.println(total_mh, 1);

  // Temp Motor  //DOWN LEFT
  display.setCursor(11, 16);
  display.println(whhour(), 0);

  // Descriptions
  display.setRotation(3);
  display.setTextSize(1);

  // TOP LEFT
  display.setCursor(19, 0);
  display.println("@H"); // Not used characters removed from glcdfont.c / actual characters changed their position

  // DOWN LEFT
  display.setCursor(3, 0);
  display.println("+H"); // Not used characters removed from glcdfont.c / actual characters changed their position

  display.setRotation(0);
}
#endif

#ifdef CONFIG_MENU
void screenConfig()
{

  setFont2WHITE();

  displayConfigValue(address, 3, 0);

  int value = 0;

  switch (address)
  {
  case 0:
    value = FIRMWARE_VERSION;
    break;

#ifdef PAS
  case 999:
    value = getCadence();
    break;
#endif

  case 998:
    value = getThrottleInputmV();
    break;

  case 997:
    value = analogRead(A3);
    break;

  case 996:
    value = int(weightOnPedal_adc_filtered.Current());
    break;

  default:
    value = EEPROM.readInt(getCfgAddress(address));
    break;
  }

  displayConfigValue(value, 5, 1);

  int x, y = 0;
  x = (configCursor - 1) * 12;
  y = 22;

  display.fillRect(x, y, 10, 2, WHITE);
}
#endif

#ifdef CONFIG_MENU
void displayConfigValue(unsigned int value, int maxlength, int startplace)
{
  int x = 0;
  int y = 6;

  if (startplace == 1)
    x = 48;

  display.setCursor(x, y);

  if (value < 10000 && maxlength == 5)
    display.print(0);

  if (value < 1000 && maxlength == 5)
    display.print(0);

  if (value < 100)
    display.print(0);

  if (value < 10)
    display.print(0);

  display.println(value);
}
#endif

#ifdef CONFIG_MENU
void selectConfig(int conf, bool updwn)
{
  int _address = getCfgAddress(address);

  if (conf < 4)
    address = changeConfigValue(address, updwn, conf);
  else
    EEPROM.updateInt(_address, changeConfigValue(EEPROM.readInt(_address), updwn, conf));
}

unsigned int changeConfigValue(unsigned int value, bool updwn, int place)
{
  unsigned int zero_nine = 0;
  unsigned int plus_minus = -1;

  if (updwn)
  {
    zero_nine = 9;
    plus_minus = 1;
  }

  if (updwn && place == 5)
    zero_nine = 6;

  switch (place)
  {
  case 3:
  case 9:
    if (value % 10 == zero_nine)
      value -= plus_minus * 9;
    else
      value += plus_minus * 1;
    break;
  case 2:
  case 8:
    if ((value / 10) % 10 == zero_nine)
      value -= plus_minus * 90;
    else
      value += plus_minus * 10;
    break;
  case 1:
  case 7:
    if ((value / 100) % 10 == zero_nine)
      value -= plus_minus * 900;
    else
      value += plus_minus * 100;
    break;
  case 6:
    if ((value / 1000) % 10 == zero_nine)
      value -= plus_minus * 9000;
    else
      value += plus_minus * 1000;
    break;
  case 5:
    if ((value / 10000) % 10 == zero_nine)
      value -= plus_minus * 60000;
    else
      value += plus_minus * 10000;
    break;
  }

  return value;
}

#endif

int intAlignRight(int value)
{

  int ret = 0;

  if (value < 10)
    ret = 105;

  if (value >= 10 && value < 100)
    ret = 93;

  if (value >= 100 && value < 1000)
    ret = 81;

  if (value >= 1000)
    ret = 69;

  if (value >= 10000)
    ret = 57;

  return ret;
}

int floatAlignRight(float value)
{
  int ret = 0;

  if (value < 10.0)
    ret = 105 - 24;

  if (value >= 10.0 && value < 100.0)
    ret = 93 - 24;

  if (value >= 100.0 && value < 1000.0)
    ret = 81 - 24;

  if (value >= 1000.0)
    ret = 69 - 24;

  return ret;
}

// ===== END MPe-oled-display.ino =====


// ===== BEGIN MPe-power.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

float getBatVoltage()
{
#ifndef TESTING
  return Convert_mVtoBatVol(pin_voltage_mV_filtered.Current());
#endif
#ifdef TESTING
  float spd = 0.0;
  spd = map(acuPercent(), 0, 100, 39.0, 54.6);
  return spd;
#endif
}

float getBatRawVoltage()
{
  return Convert_mVtoBatVol(ads.readADC_SingleEnded(PIN_VOLTAGE) * 0.1875);
}

void checkVRef()
{
  vRef_filtered.Filter(ads.readADC_SingleEnded(PIN_V_REFERENCE) * 0.0001875);
  vRef = vRef_filtered.Current();
}

float getCurrent()
{
  float current = Convert_mVtoAmp(pin_current_mV_filtered.Current());
  if (current < 0.5 && current > -0.5)
    current = 0.00;

#ifndef TESTING
  return current;
#endif

#ifdef TESTING
  return randomcurrent;
#endif
}

void checkCurrentAndVoltage()
{
  unsigned int time = 0;
  time = (millis() - timer_30ms_loop);

  if (time > T30MS_LOOP)
  {
    timer_30ms_loop = millis();

    int pin_voltage_mV = (ads.readADC_SingleEnded(PIN_VOLTAGE) * 0.1875);
    pin_voltage_mV_filtered.Filter(pin_voltage_mV);

    float pin_current_mV = ads.readADC_SingleEnded(PIN_CURRENT) * 0.1875;
    pin_current_mV_filtered.Filter(pin_current_mV);

    float current = getCurrent();
    float pwr = getPower();
    float wh_to_add = 0.0;

#ifndef TESTING
    if (current > imax && millis() > 5000)
    {
      imax = current;
      if (pwr > powermax)
        powermax = pwr;
    }
#endif

#ifdef TESTING

    if (getPower() > powermax)
      powermax = getPower();

    if (getCurrent() > imax)
      imax = getCurrent();
#endif

    mah_used += current * time / 3600.0;

    if (mah_used < 0)
      mah_used = 0;

    // power and whused calculations

    wh_to_add = pwr * time / 3600000.0; // /1000.0/3600.0

    Wh_used += wh_to_add;

    if (Wh_used < 0.0)
      Wh_used = 0.0;

    if (pwr > 0.0)
    {
      total_ah_used += current * time / 3600000.0; // /1000.0/3600.0
      Wh_used_trp += wh_to_add;
      Wh_used_dtg += wh_to_add;
#ifdef MTG
      Wh_used_mtg += wh_to_add;
#endif
    }
  }
}

float getPower()
{
  float pwr = getBatVoltage() * getCurrent();

  return pwr;
}

// ===== END MPe-power.ino =====


// ===== BEGIN MPe-serial.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

#ifdef SERIALPLOT
void printComma()
{
  DEBUG_PR(",");
}
#endif

void serialPrintInfo()
{

  if (millis() - timer_send_uart > TIME_SEND_UART)
  {
    if (EEPROM.readInt(ADR_PRINTINFO))
    {
      mySerial.write("MPe;");
      mySerial.printsc(speed, 1);
      mySerial.printsc(distToGo());
      mySerial.printsc(acuPercent());
      mySerial.printsc(trip, 1);
      mySerial.printsc(int(getPower()));
      mySerial.printsc(int(getTemp_1()));
      mySerial.printsc(EEPROM.readInt(ADR_ASSISTMODE));
      mySerial.printsc(int(dist));
      mySerial.printsc(int(avgSpeed()));
      mySerial.printsc(int(vmax));
      mySerial.printsc(int(moving_time));
      mySerial.printsc(getBatVoltage(), 1);
      mySerial.printsc(getCurrent(), 1);
      mySerial.printsc(int(imax));
      mySerial.printsc(int(powermax));
      mySerial.printsc(whkm(), 1);
      mySerial.printsc((EEPROM.readInt(ADR_BATCAP_AH) / 10.0), 1);
      mySerial.printsc((mah_used / 1000), 1);
      mySerial.printsc(int(getTemp_2()));
      mySerial.printsc(numberCharges());
      mySerial.printsc(brake);
      mySerial.printsc(cruisecontrol);
      mySerial.printsc(FIRMWARE_VERSION);
      mySerial.printsc(EEPROM.readInt(ADR_LEGALLIMIT_ON_OFF));
      mySerial.printsc(int(Wh_used));
      mySerial.printsc(!rideOK);
#ifdef PAS
      mySerial.printsc(getCadence());
#endif
#ifndef PAS
      mySerial.printsc(0);
#endif
      mySerial.printsc(getThrottleInputmV());
#ifdef PAS
      mySerial.printsc(analogRead(A3));                        // adc torque sensor
      Serial.print(int(weightOnPedal_adc_filtered.Current())); // kgF
#endif
#ifndef PAS
      mySerial.printsc(0);
      mySerial.print(0);
#endif
      mySerial.println(";");
    }

    timer_send_uart = millis();
  }
}

void serialConfig()
{

  if (Serial.available() > 1)
  {
    int action = 0;
    int address = 400;
    int value = 0;

    action = Serial.parseInt();

    if (action == 6004)
    {
      cruisecontrol = 0;
      SetThrRelResetFALSE();

      action = Serial.parseInt();

      switch (action)
      {
      case 1: // read INT
        address = Serial.parseInt();

        Serial.print("CFG;");
        mySerial.printsc(address);

        Serial.print(EEPROM.readInt(address));
        Serial.println(";");

        break;

      case 2: // save INT
        address = Serial.parseInt();
        value = Serial.parseInt();

        if (address == ADRDIST || address == ADRTOTMAHUSED)
          EEPROM.updateFloat(address, value);
        else if ((address == ADRFIRSTTIME) || (address % 2))
          break;
        else
          EEPROM.updateInt(address, value);
        break;

      case 3:
        resetCurrentAt0();
        break;

      case 4:
        zeroTrip();
        break;

      case 5:
        resetBattery();
        break;

      case 6:
        printAllConfig();
        break;

      case 7:
        enableCruiseControl();
        break;

      case 8:
        cruisecontrol = 1;
        slowDownCruiseControl();
        break;

      case 9:
        cruisecontrol = 1;
        speedUpCruiseControl();
        break;

#ifdef LIGHT_OPERATION
      case 11:
        if (!D4_state && !D9_state && !LCD_dark)
        {
          D4_state = !D4_state;
          digitalWrite(4, D4_state);
          LCD_dark = !LCD_dark;
        }
        else if (D4_state && !D9_state && LCD_dark)
        {
          LCD_dark = !LCD_dark;
        }
        else if (D4_state && !D9_state && !LCD_dark)
        {
          D9_state = !D9_state;
          digitalWrite(9, D9_state);
          LCD_dark = !LCD_dark;
        }
        else if (D4_state && D9_state && LCD_dark)
        {
          D9_state = !D9_state;
          digitalWrite(9, D9_state);
          D4_state = !D4_state;
          digitalWrite(4, D4_state);
          LCD_dark = !LCD_dark;
        }

        break;
#endif
      }
#ifdef TESTING
      saveData();
#endif
    }
  }
}

void printAllConfig()
{

  Serial.print("ALL;");

  for (int i = 200; i < 512; i += 2)
  {
    mySerial.printsc(EEPROM.readInt(i));
  }
  Serial.println("#END");
}

// ===== END MPe-serial.ino =====


// ===== BEGIN MPe-speed.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

void checkIfStopped()
{
  int time = 2500;
  if ((EEPROM.readInt(ADR_MOT_MAG) > 1))
    time = 1000;

  if ((millis() - timer_stopped > time) && !stopped)
  {
    stopped = true;
    speed_filtered.SetCurrent(0.0);
    saveData();
  }
}

float avgSpeed()
{

  float avg = 0.0;
  avg = trip / moving_time * 60.0;

  if (isinf(avg) || isnan(avg))
    avg = 0.0;

  return avg;
}

void mot_rot()
{
  rotation_impulses++;
}

void speed_one()
{
  if (!speed_impulse) // debouncing
    speedOneimpulseTime = millis() - timer_speed_one;

  speed_impulse = true;

  timer_speed_one = millis();
}


void speed_one_check()
{
  if (millis() - timer_30ms_loop > T30MS_LOOP)
  {
    if (speed_impulse)
    {

      stopped = false;

      detachInterrupt(PIN_DSPEED);
      speed_impulse = false;
      attachInterrupt(digitalPinToInterrupt(PIN_DSPEED), speed_one, FALLING);

      float spd = 0.0;
      spd = EEPROM.readInt(ADR_PERIMETER) * 3.4344 / speedOneimpulseTime; // experimental: 3.4344 instead of 3.6   because it seems like in real life readings are ~5% higher, so we decreasing perimeter about 5%
      speed_filtered.Filter(spd);
      timer_stopped = millis();
    }
  }
}


void speed_multi(int time)
{
  unsigned int rot_imp = 0;
  float rpm = 0.0;
  float rps = 0.0;
  float spd = 0.0;
  // detachInterrupt(PIN_DSPEED);
  detachInterrupt(digitalPinToInterrupt(PIN_DSPEED));
  rot_imp = rotation_impulses;
  rotation_impulses = 0;
  attachInterrupt(digitalPinToInterrupt(PIN_DSPEED), mot_rot, FALLING);

  rps = (rot_imp * (1000.0 / time)) / (EEPROM.readInt(ADR_MOT_MAG) / 2);

  rpm = rps * 60.0;
  spd = (rpm / 1000.0) / (EEPROM.readInt(ADR_GEAR_RATIO) / 10.0) * 60.0 * (EEPROM.readInt(ADR_PERIMETER) / 1050.0); // experimental: 1050.0 becouse it seems like in real life readings are ~5% higher, so we decreasing perimeter about 5%
  speed_filtered.Filter(spd);

  if (spd > 1.0)
  {
    stopped = false;
    timer_stopped = millis();
  }
}

void countSpeed()
{
  int time = millis() - timer_speed;

  if (time >= SPEED_COUNT_TIME)
  {
    timer_speed = millis();

    if ((EEPROM.readInt(ADR_MOT_MAG) > 1))
      speed_multi(time);

    speed = speed_filtered.Current();

    if (EEPROM.readInt(ADR_KPHMPH))
      speed = speed * 0.621;

    if (speed > vmax)
      vmax = speed;

    float add_distance = (speed / 3600.0) * (time / 1000.0);

    dist += add_distance;
    if (dist > 50000)
      dist = 0;

    trip += add_distance;
    trip_dtg += add_distance;

    if (!stopped)
    {
      moving_time += time / 60000.0;

#ifdef MTG
      moving_time_mtg += time / 60000.0;
      total_mh += time / 3600000.0;
#endif
    }
  }
}

// ===== END MPe-speed.ino =====


// ===== BEGIN MPe-temperature.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

float convertCtoF(float temp)
{
  return (temp * 1.8) + 32.0;
}

int Convert_VtoTempLM35(float voltage)
{
  float temp = 0.0;
  temp = voltage * 100.0;
  return int(temp);
}

int Convert_VtoTempThermistor(float v_in, int type) //[V]
{
  float coef_A = A_10K;
  float coef_B = B_10K;
  float coef_C = C_10K;

  if (type == 2 || type == 4)
  {
    coef_A = A_KTY83;
    coef_B = B_KTY83;
    coef_C = C_KTY83;
  }

  float Rs = ((TEMPRESVAL * (vRef - 0.67)) / v_in) - TEMPRESVAL; // resistance of thermistor

  if (type == 3 || type == 4)
    Rs = TEMPRESVAL / ((((vRef / v_in) - 1.0) * (TEMPRESVAL / TEMPRESVAL2)) - 1.0); // Resistance of thermistor Mxus3k Turbo (common ground with hall)

  // T = 1/(a + b×ln(Rs) + c×(ln(Rs))3 )  http://www.useasydocs.com/theory/ntc.htm

  float lnRs = log(Rs);

  float temp = (1 / (coef_A + (coef_B * lnRs) + (coef_C * (lnRs * lnRs * lnRs)))) - 273.15;

  return int(temp);
}

int getTemp_1()
{
#ifndef TESTING
  return getTemp(pin_temp1_V_filtered.Current(), EEPROM.readInt(ADR_TEMPTYPE1));
#endif
#ifdef TESTING
  return randomtemp1;
#endif
}

int getTemp_2()
{
#ifndef TESTING
  return getTemp(pin_temp2_V_filtered.Current(), EEPROM.readInt(ADR_TEMPTYPE2));
#endif
#ifdef TESTING
  return randomtemp2;
#endif
}

int getTemp(float tempPinV, int type)
{
  int temp = 0;

  if (type == 0)
    temp = Convert_VtoTempLM35(tempPinV);
  else
    temp = Convert_VtoTempThermistor(tempPinV, type);

  if (EEPROM.readInt(ADR_TEMPCTEMPF))
    return convertCtoF(temp);
  else
    return temp;
}

void checkTemp()
{
  float pin_temp_V = vRef / 1024.0 * analogRead(PIN_LM35_TEMP_T1);
  pin_temp1_V_filtered.Filter(pin_temp_V);

  pin_temp_V = vRef / 1024.0 * analogRead(PIN_LM35_TEMP_T2);
  pin_temp2_V_filtered.Filter(pin_temp_V);

  if ((getTemp_1() > int(EEPROM.readInt(ADR_OVHT1)) || getTemp_2() > int(EEPROM.readInt(ADR_OVHT2))) && temperatureOK)
  {
    temperatureOK = false;
  }

  if (!temperatureOK)
  {
    if (getTemp_1() < int(EEPROM.readInt(ADR_OVHT1)) - 10 && getTemp_2() < int(EEPROM.readInt(ADR_OVHT2)) - 10)
      temperatureOK = true;
  }
}

// ===== END MPe-temperature.ino =====


// ===== BEGIN MPe-throttle-pas.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

int16_t getThrottleInputmV()
{
  return ads.readADC_SingleEnded(PIN_THROTTLE_IN) * 0.01875;
}

void setThrottle()
{
#ifdef PAS
  // PID Compute
  float pwr = 0.0;
  pwr = getPower();

  if (pwr < 0)
    pwr = 0;

  pPID_In = pwr;

  pidTune();

#ifndef SERIALPLOT
  powerPID.Compute();
  pwmOut = (int)pPID_Out;
#endif

  // Serial Print for graph plotting
#ifdef SERIALPLOT
  bool plot_print = powerPID.Compute(); // synchoronize print with PID compute
  float power_in = pPID_In;
  pwmOut = (int)pPID_Out;
#endif

#endif

  unsigned int tot_min = EEPROM.readInt(ADR_TOT_MIN);
  unsigned int tot_max = EEPROM.readInt(ADR_TOT_MAX);
  unsigned int tin_min = EEPROM.readInt(ADR_TIN_MIN);
  unsigned int tin_max = EEPROM.readInt(ADR_TIN_MAX);

  tot_min = constrain(tot_min, 60, 120); // prevent motor from self running due to set wrong values or eeprom corruption
  tot_max = constrain(tot_max, 300, 430);
  tin_min = constrain(tin_min, 70, 150);
  tin_max = constrain(tin_max, 300, 430);

  int pwmout_min = int((((tot_min / 100.0) * 255.0) / 4.75)); // 4.75V is reference voltage - 0.25V due to voltage drop on TOT connector when connetced to controller. It has to be fixed value (4.75) becouse damaged ADS1115 causes motor to self run if this value was set as vRef
  int pwmout_max = int((((tot_max / 100.0) * 255.0) / 4.75));

  int thrinminPLUS = tin_min + 5;

  int16_t pin_thrIn_mV = 0;
  pin_thrIn_mV = getThrottleInputmV();

  bool thumb_throttle_active = pin_thrIn_mV > thrinminPLUS;

  int assistmode = EEPROM.readInt(ADR_ASSISTMODE);
  int throttlemode = 0;
  int assistmodeadd = 2 * (assistmode - 1);

  // Cruise control deactivation from throttle input
  if (cruisecontrol && thumb_throttle_active)
  {
    cruisecontrol = false;
  }
  //===

  // Throttle release reset after brake pressed
  if (throttle_relased_reset == false && !thumb_throttle_active)
    throttle_relased_reset = true;
  //===

  if (rideOK)
  {
    bool legallimit = EEPROM.readInt(ADR_LEGALLIMIT_ON_OFF);
    unsigned int set = 0;

    // SpeedFactor selector variables
    unsigned int spd_max = 0;
    unsigned int spd_max_min5 = 0;
    unsigned int CC_max_speed = 0;
    unsigned int power = 0;
    unsigned int cadence_min = 0;
    unsigned int cadence_max = 0;
    unsigned int ramp_up_dwn = 0;
    //===

#ifdef PAS
    int cadence = getCadence();
#endif

#ifndef PAS
    int cadence = 0;
#endif

    // Throttle mode selector
    if (cruisecontrol && !legallimit) // cruisecontrol
    {
      throttlemode = 4;
    }
    else if ((!thumb_throttle_active || legallimit) && !cruisecontrol && ((cadence > EEPROM.readInt(ADR_CAD_MIN_PAS_1 + assistmodeadd) && checkMinimumHumanPower()) || checkStartupWeightOnPedal())) // PAS
    {
      throttlemode = 3;
    }
    else if ((EEPROM.readInt(ADR_MODE_THR_1 + assistmodeadd) == 1) && !legallimit) // throttle power
    {
      throttlemode = 2;
    }
    else if ((EEPROM.readInt(ADR_MODE_THR_1 + assistmodeadd) == 0) && !legallimit) // throttle voltage
    {
      throttlemode = 1;
    }
    //===

    switch (throttlemode)
    {
    case 1: // throttle voltage

#ifdef PAS
      pPID_Set = 0;
      ZeroNoPedallingTimer();
#endif

      if (throttle_relased_reset)
      {

        unsigned int pwr_limit = EEPROM.readInt(ADR_PWR_LIM_THR_1 + assistmodeadd);
        pwr_limit = constrain(pwr_limit, 0, 100);

        set = mapConstrain(pin_thrIn_mV, tin_min, tin_max, tot_min, tot_max * 0.01 * pwr_limit);

        voltageOut = valueDelay(voltageOut, set, EEPROM.readInt(ADR_RAMP_UP_THR_1 + assistmodeadd), 10000, 1);

        pwmOut = mapConstrain(voltageOut, tot_min, tot_max, pwmout_min, pwmout_max);
      }
      else
        pwmOut = pwmout_min;

      break;

#ifdef PAS
    case 2: // throttle power

      pas_after_power_throttle = true;

      power = EEPROM.readInt(ADR_PWR_LIM_THR_1 + assistmodeadd);
      power = constrain(power, 0, 1000);

      if (throttle_relased_reset)
      {
        set = mapConstrain(pin_thrIn_mV, tin_min, tin_max, 0, power);

        pPID_Set = valueDelay(pPID_Set, set, EEPROM.readInt(ADR_RAMP_UP_THR_1 + assistmodeadd), 5000, 1);
      }
      else
        pPID_Set = 0;

      break;
#endif

#ifdef PAS
    case 3: // PAS

      if (pas_after_power_throttle)
      {
        pPID_Set = 0;
        pas_after_power_throttle = false;
      }

      if ((speed >= EEPROM.readInt(ADR_MIN_SPD_PAS_1 + assistmodeadd) && speed >= 0.15) || checkStartupWeightOnPedal())
      {
        spd_max = EEPROM.readInt(ADR_SPD_LIM_PAS_1 + assistmodeadd);
        if (spd_max > 50)
          spd_max = 50;
        spd_max_min5 = spd_max - 5;

        cadence_min = EEPROM.readInt(ADR_CAD_MIN_PAS_1 + assistmodeadd);
        cadence_max = EEPROM.readInt(ADR_CAD_MAX_PAS_1 + assistmodeadd);

        power = EEPROM.readInt(ADR_PWR_LIM_PAS_1 + assistmodeadd);

        // SET POWER FROM CADENCE AND SPEED - START
        if (legallimit)
        {

          if (spd_max > EEPROM.readInt(ADR_LEGALLIMIT_SPEED))
          {
            spd_max = EEPROM.readInt(ADR_LEGALLIMIT_SPEED);
            spd_max_min5 = spd_max - 5;
          }

          if (power > EEPROM.readInt(ADR_LEGALLIMIT_POWER))
            power = EEPROM.readInt(ADR_LEGALLIMIT_POWER);
        }

        ramp_up_dwn = EEPROM.readInt(ADR_SPEEDFACTOR_RAMP_UP);

        set = int(mapConstrain(int(speed * 10), spd_max_min5 * 10, spd_max * 10, 100, EEPROM.readInt(ADR_SPEEDFACTORMIN)));
        speedFactor = valueDelay(speedFactor, set, ramp_up_dwn, ramp_up_dwn, 1);

        ramp_up_dwn = EEPROM.readInt(ADR_RAMP_UP_PAS_1 + assistmodeadd);
        set = int(mapConstrain(getCadence(), cadence_min, cadence_max, 0, power) * (speedFactor / 100.0));
        // SET POWER FROM CADENCE AND SPEED - END

        // SET POWER FROM TORQUE SENSOR, CADENCE AND SPEED - START
        if (power <= 20 && EEPROM.readInt(ADR_ENABLE_TORQUE_SENSOR))
          set = int(humanPower_adc_filtered.Current() * power * 0.5 * (speedFactor / 100.0));

        if (legallimit)
        {
          if (set > EEPROM.readInt(ADR_LEGALLIMIT_POWER))
            set = EEPROM.readInt(ADR_LEGALLIMIT_POWER);
        }
        // SET POWER FROM TORQUE SENSOR, CADENCE AND SPEED - END

        if (set > 3000)
          set = 3000;

        unsigned long zero_cadence_time = millis() - timer_no_pedalling;

        // PAS FAST_STARTUP START
        if (zero_cadence_time < 300)
        {
          if ((cadence > cadence_min && checkMinimumHumanPower()) || checkStartupWeightOnPedal())
          {
            set = 350;
            ramp_up_dwn = 5000;
          }
        }
        // PAS FAST_STARTUP END

        // PAS BOOST START
        if (!legallimit)
        {
          if (zero_cadence_time < EEPROM.readInt(ADR_BOOST_TIME_PAS_1 + assistmodeadd))
          {
            if (int(speed) < EEPROM.readInt(ADR_BOOST_SPEED_PAS_1 + assistmodeadd))
            {
              if (cadence > cadence_min)
              {
                set = EEPROM.readInt(ADR_BOOST_POWER_PAS_1 + assistmodeadd);
                ramp_up_dwn = EEPROM.readInt(ADR_BOOST_RAMP_UP_PAS);
              }
            }
          }
        }
        // PAS BOOST END

        // Finally set the PID for PAS
        pPID_Set = float(valueDelay(int(pPID_Set), set, ramp_up_dwn, ramp_up_dwn, 2));
      }
      else
        pPID_Set = 0;

      break;
#endif

#ifdef PAS
    case 4: // cruisecontrol

      spd_max = cruisecontrol_speed;
      spd_max_min5 = spd_max - 5;

      CC_max_speed = EEPROM.readInt(ADR_CRUISE_CONTROL_MAX_SPEED);

      if (CC_max_speed > 45)
        CC_max_speed = 45;

      power = mapConstrain(spd_max, 5, CC_max_speed, EEPROM.readInt(ADR_CRUISE_CONTROL_POWER_MIN), EEPROM.readInt(ADR_CRUISE_CONTROL_POWER_MAX));

      if (power > 2000)
        power = 2000;

      ramp_up_dwn = EEPROM.readInt(ADR_SPEEDFACTOR_RAMP_UP);

      set = int(mapConstrain(int(speed * 10), spd_max_min5 * 10, spd_max * 10, 100, EEPROM.readInt(ADR_SPEEDFACTORMIN)));
      speedFactor = valueDelay(speedFactor, set, ramp_up_dwn, ramp_up_dwn, 1);

      ramp_up_dwn = EEPROM.readInt(ADR_CRUISE_CONTROL_POWER_RAMP_UP);
      set = int(power * (speedFactor / 100.0));

      pPID_Set = float(valueDelay(int(pPID_Set), set, ramp_up_dwn, ramp_up_dwn, 2));

      break;
#endif

    default:
#ifdef PAS
      pPID_Set = 0;
#endif
      pwmOut = pwmout_min;
      break;
    }
#ifdef PAS
    if (pPID_Set < 5)
      powerPID.RESET();
#endif

    analogWrite(PIN_THROTTLE_OUT, pwmOut);
  }
  else
  {
#ifdef PAS

    pPID_In = 20000;
    pPID_Set = 0;
    powerPID.RESET();
#endif
    cruisecontrol = false;

    voltageOut = 80;

    analogWrite(PIN_THROTTLE_OUT, pwmout_min);
  }

#ifdef SERIALPLOT
  if (plot_print && EEPROM.readInt(ADR_SERIAL_PLOT))
  {
    DEBUG_PR(int(power_in));
    printComma();
    DEBUG_PR(int(pPID_Set));
    printComma();
    DEBUG_PR(int(speed * 10));
    printComma();
    DEBUG_PR(int(analogRead(A3)));
    printComma();
    DEBUG_PR(int(weightOnPedal_adc_filtered.Current()));
    printComma();
    DEBUG_PR(int(getCadence()));
    printComma();
    DEBUG_PRLN(int(humanPower_adc_filtered.Current()));
  }
#endif
}

void checkIfrideOK()
{
  int assistmode = EEPROM.readInt(ADR_ASSISTMODE);

  int16_t pin_thrIn_mV = 0;
  pin_thrIn_mV = ads.readADC_SingleEnded(PIN_THROTTLE_IN) * 0.01875;

  if (
      (getBatVoltage() >= EEPROM.readInt(ADR_LVC) / 10.0) && temperatureOK && !brake && (assistmode > 0) && (getCurrent() >= -((float)EEPROM.readInt(ADR_CUR_PROT))) && (pin_thrIn_mV < EEPROM.readInt(ADR_THR_SAFE_VOLTAGE))) // 370))

    rideOK = true;

  else

    rideOK = false;
}

void SetThrRelResetFALSE()
{
  throttle_relased_reset = false;
}

void enableCruiseControl()
{
  if (!cruisecontrol && screen == 1 && !EEPROM.readInt(ADR_LEGALLIMIT_ON_OFF) && (EEPROM.readInt(ADR_CRUISE_CONTROL_MAX_SPEED) > 0))
  {
    cruisecontrol = 1;
    cruisecontrol_speed = speed + 3.5;
    if (cruisecontrol_speed > 45.0)
      cruisecontrol_speed = 45.0;
  }
}

void slowDownCruiseControl()
{
  if (cruisecontrol && cruisecontrol_speed > 6.0)
    cruisecontrol_speed -= 2.0;
}

void speedUpCruiseControl()
{
  if (cruisecontrol && cruisecontrol_speed < 45.0 && !screenconfig)
    cruisecontrol_speed += 2.0;
}

void ZeroNoPedallingTimer()
{
  timer_no_pedalling = millis();
}

bool checkStartupWeightOnPedal()
{
  int min_spd = EEPROM.readInt(ADR_MIN_SPD_PAS_1 + (2 * (EEPROM.readInt(ADR_ASSISTMODE) - 1)));
  if (EEPROM.readInt(ADR_ENABLE_TORQUE_SENSOR))
    return weightOnPedal_adc_filtered.Current() > EEPROM.readInt(ADR_STARTUP_WEIGHT_ON_PEDAL) && speed < 5.0 && speed >= min_spd;
  else
    return 0;
}

bool checkMinimumHumanPower()
{
  int power = EEPROM.readInt(ADR_PWR_LIM_PAS_1 + (2 * (EEPROM.readInt(ADR_ASSISTMODE) - 1)));
  if (EEPROM.readInt(ADR_ENABLE_TORQUE_SENSOR) && power < 21)
    return humanPower_adc_filtered.Current() > 3 || weightOnPedal_adc_filtered.Current() > 10;
  else
    return 1;
}

#ifdef PAS
void checkTorque()
{
  int analog_torque = analogRead(A3);
  weightOnPedal_adc_filtered.Filter(mapConstrain(analog_torque, EEPROM.readInt(ADR_TORQUE_SENSOR_ADC_MIN), EEPROM.readInt(ADR_TORQUE_SENSOR_ADC_MAX), 0, EEPROM.readInt(ADR_TORQUE_SENSOR_KGF_MAX))); // max torque sensor force is 60kgF, multiplied by 10 to have decimal point values as int

  humanPower_adc_filtered.Filter((weightOnPedal_adc_filtered.Current() * getCadence()) / 55);

  // if just rotatnig cranks without force
  if (!checkMinimumHumanPower())
    ZeroNoPedallingTimer();
}
#endif

#ifdef PAS
void pas_rot()
{
  pas_rotation_impulses++;
}

int getCadence()
{
  return pas_rpm_ex.Current();
}

void checkCadence()
{
  int time = millis() - timer_pas_rpm;
  int impulses = 0;
  float pas_rps = 0.0;
  float pas_rpm = 0.0;

  int interval = EEPROM.readInt(ADR_CADENCE_COUNT_TIME);

  if (time >= interval)
  {

    detachInterrupt(PIN_PAS);

    impulses = pas_rotation_impulses;
    pas_rotation_impulses = 0;
    timer_pas_rpm = millis();

    attachInterrupt(digitalPinToInterrupt(PIN_PAS), pas_rot, CHANGE);

    pas_rps = (impulses * 500.0 / time) / (EEPROM.readInt(ADR_PASMAGNETS));

    pas_rpm = pas_rps * 60.0;

    pas_rpm_ex.Filter(pas_rpm);

    if (impulses == 0)
    {
      pas_rpm_ex.SetCurrent(0);
      ZeroNoPedallingTimer();
      if (!cruisecontrol)
        speedFactor = 100;
    }
  }
}

#endif

#ifdef PAS
void pidTune()
{

  int spd = 1;

  if (abs(pPID_Set - pPID_In) >= EEPROM.readInt(ADR_LOW_THRESHOLD))
    spd = 0;

  switch (spd)
  {
  case 0: // power PID fast
    powerPID.SetTunings(EEPROM.readInt(ADR_POWERKP) / 10000.0, EEPROM.readInt(ADR_POWERKI) / 1000.0, EEPROM.readInt(ADR_POWERKD) / 100000.0, 1);
    break;

  case 1: // power PID slow
    powerPID.SetTunings(EEPROM.readInt(ADR_P_LOW) / 10000.0, EEPROM.readInt(ADR_I_LOW) / 1000.0, EEPROM.readInt(ADR_D_LOW) / 100000.0, 1);
    break;
  }
}
#endif

// ===== END MPe-throttle-pas.ino =====


// ===== BEGIN MPe-utilities.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

#ifdef TESTING
void testRandom()
{
  randomcurrent = random(0, 50) + random(0, 10) / 10.0;
  randomtemp1 = random(15, 150) + random(0, 10) / 10.0;
  randomtemp2 = random(15, 70) + random(0, 10) / 10.0;
  randomspeedms = random(0, 50);
}
#endif

int valueDelay(int value, int set, int step_up, int step_down, int timer_no) // step_up (or down) means value_unit per second ex. 10V = 10V/s, 10W = 10W/s
{
  unsigned int time = 0;

  if (timer_no == 1)
  {
    time = millis() - timer_value_delay_1;
    timer_value_delay_1 = millis();
  }
  else if (timer_no == 2)
  {
    time = millis() - timer_value_delay_2;
    timer_value_delay_2 = millis();
  }

  if ((set > value))
  {
    value += step_up / (1000 / time);
    if (value > set)
      value = set;
  }
  else if ((set < value))
  {
    value -= step_down / (1000 / time);
    if (value < set)
      value = set;
  }

  return value;
}

int mapConstrain(int value, int fromLow, int fromHigh, int toLow, int toHigh)
{
  value = constrain(value, fromLow, fromHigh);

  return map(value, fromLow, fromHigh, toLow, toHigh);
}

float Convert_mVtoBatVol(int mV)
{
  float ret = 0.0;
  ret = EEPROM.readInt(ADR_VOL_DIV) / 1000000.0 * mV;

  return ret;
}

void set_adc_offset()
{
  unsigned long time = millis() - timer_adc_offset;
  adc_will_save = 1;
  if (time < 5000)
  {
    adc_offset = (adc_offset + ((vRef_filtered.Current() * 500.0) - pin_current_mV_filtered.Current())) / 2.0;
    adc_will_save = 0;
  }

  if (adc_will_save && !adc_saved)
  {
    adc_saved = 1;
    EEPROM.updateFloat(ADR0CURRENT, adc_offset);
  }
}

float Convert_mVtoAmp(float mV)
{
  float ret = 0.0;
  float cur_dir = 1.0;
  if (EEPROM.readInt(ADR_CURDIR))
    cur_dir = -1.0;

  ret = cur_dir * ((vRef_filtered.Current() * 500.0) - eepromLoadFloat(ADR0CURRENT) - mV) / float(EEPROM.readInt(ADR_MVPERA));

  return ret;
}

int acuPercent()
{
  int acupercent = int(((EEPROM.readInt(ADR_BATCAP_AH) * 100.0) - mah_used) / (EEPROM.readInt(ADR_BATCAP_AH) * 100.0) * 100.0);

  if (acupercent < 0)
    acupercent = 0;

  return acupercent;
}

int numberCharges()
{
  return int(total_ah_used / (EEPROM.readInt(ADR_BATCAP_AH) / 10.0));
}

float whkm()
{
  float whkm = Wh_used_trp / trip;
  if (isnan(whkm) || isinf(whkm))
    whkm = 0.0;

  return whkm;
}

int whkm_dtg()
{
  int whkm = int(Wh_used_dtg / trip_dtg);
  if (isinf(whkm))
    whkm = 0;

  return whkm;
}

int distToGo()
{

  float dtg = 0.0;

  dtg = (EEPROM.readInt(ADR_BATCAP_WH) - Wh_used) / whkm_dtg();

  if (trip_dtg > 4.0)
  {
    last_dtg = dtg;
    trip_dtg = 0.0;
    Wh_used_dtg = 0.0;
    saveData();
  }

  if (last_dtg > 0 && trip_dtg < 1.0)
    dtg = last_dtg;

  if (isinf(dtg) || dtg > 999)
    dtg = 999;

  if (dtg < 3)
    dtg = 0;

  return dtg;
}

#ifdef MTG
float whhour()
{
  float whhour = Wh_used_trp / moving_time * 60.0;
  if (isnan(whhour) || isinf(whhour))
    whhour = 0;

  return whhour;
}

float whhour_mtg()
{
  float whhour = Wh_used_mtg / moving_time_mtg * 60.0;
  if (isnan(whhour) || isinf(whhour))
    whhour = 0;

  return whhour;
}

float minutesToGo()
{

  float mtg = 0.0;
  mtg = int((EEPROM.readInt(ADR_BATCAP_WH) - Wh_used) / (whhour_mtg() / 60.0));

  if (moving_time_mtg > 5.0)
  {
    last_mtg = mtg;
    moving_time_mtg = 0.0;
    Wh_used_mtg = 0.0;
    saveData();
  }

  if (last_mtg > 0.0 && moving_time_mtg < 1)
    mtg = last_mtg;

  if (isinf(mtg) || mtg > 999)
    mtg = 999;

  if (mtg < 0)
    mtg = 0;

  return mtg;
}
#endif

void resetCurrentAt0()
{
  timer_adc_offset = millis();
  adc_saved = 0;
}

void resetBattery()
{
#ifndef TESTING
  float vol = 0.0;
  float percent = 0.0;

  vol = getBatRawVoltage();
  int lvc = (EEPROM.readInt(ADR_LVC) / 10.0) + 2;
  percent = ((vol - lvc) / ((EEPROM.readInt(ADR_FULL_BATT_V) / 10.0) - lvc)) + 0.05;

  if (percent > 1.0)
    percent = 1.0;

  if (percent < 0.0)
    percent = 0.0;

  float batWh = float(EEPROM.readInt(ADR_BATCAP_WH));
  float batAh = float(EEPROM.readInt(ADR_BATCAP_AH) * 100.0);

  Wh_used = batWh - (batWh * percent);
  mah_used = batAh - (batAh * percent);
  saveData();
#endif

#ifdef TESTING
  Wh_used = 0.0;
  mah_used = 0.0;
  saveData();
#endif
}

void zeroTrip()
{
  trip = 0.0;
  trip_dtg = 0.0;
  vmax = 0.0;
  moving_time = 0.0;
  Wh_used_trp = 0.0;
  Wh_used_dtg = 0.0;
  last_dtg = 0;
  powermax = 0.0;
  imax = 0.0;

#ifdef MTG
  Wh_used_mtg = 0.0;
  moving_time_mtg = 0.0;
  last_mtg = 0.0;
#endif

  saveData();
}

int getCfgAddress(int address)
{
  if (address == 0 || address > 150)
    address = 200;

  address = 200 + address * 2;

  return address;
}

// ===== END MPe-utilities.ino =====


// ===== BEGIN MPe-watchdog.ino =====
/*
 * This file is part of MPe-firmware.
 *
 * MPe-firmware is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MPe-firmware is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MPe-firmware.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2022 Marek Przybylak
 */

void enable_watchdog()
{
  cli();
  wdt_reset();
  WDTCSR |= B00011000;
  // WDTCSR =  B01001100;   //0.25s
  // WDTCSR =  B01001101;   //0.5s
  WDTCSR = B01001110; // 1.0s
  sei();
}

// WATCHDOG Interrupt
ISR(WDT_vect)
{
  EEPROM.updateInt(ADR_WATCHDOGRESET, 1);
  saveData();
}

// ===== END MPe-watchdog.ino =====

