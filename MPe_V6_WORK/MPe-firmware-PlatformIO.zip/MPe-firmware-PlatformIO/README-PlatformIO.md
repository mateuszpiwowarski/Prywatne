# MPe-firmware — projekt przeniesiony do PlatformIO

Ten katalog został przygotowany z archiwum Arduino IDE do użycia w VS Code + PlatformIO.

## Założenia
- Projekt źródłowy opisuje sprzęt jako **Atmega328P / Arduino**.
- W `MPe-configuration.h` jest uwaga: **"USE BOOTLOADER FROM ARDUINO UNO"**.
- Dlatego domyślna konfiguracja w `platformio.ini` używa `board = uno`.

## Struktura
- `src/` — ujednolicony szkic `main.ino` i nagłówki projektu
- `sketch-parts/` — oryginalne podzielone pliki `.ino` zachowane jako referencja
- `lib/` — lokalne biblioteki przeniesione z katalogu głównego
- `platformio.ini` — konfiguracja PlatformIO

## Pierwsze uruchomienie
1. Otwórz ten folder w VS Code.
2. Upewnij się, że masz zainstalowane rozszerzenie **PlatformIO IDE**.
3. Otwórz `platformio.ini` i w razie potrzeby zmień `board`, jeśli używasz innej płytki z ATmega328P.
4. Kliknij **Build**.
5. Jeśli upload idzie na zły port, dopisz np.:
   - `upload_port = COM5`
   - `monitor_port = COM5`
6. Monitor szeregowy działa z prędkością `9600`.

## Uwagi
- Biblioteki zostały zachowane jako **lokalne kopie** w `lib/`, więc projekt nie wymaga ręcznego instalowania ich z rejestru PlatformIO.
- Główny szkic został scalony do `src/main.ino`, aby zachować zachowanie Arduino IDE przy projekcie wieloplikowym.
- Nie wykonywałem końcowej kompilacji w tym środowisku, bo nie ma tu zainstalowanego PlatformIO ani toolchaina AVR.
